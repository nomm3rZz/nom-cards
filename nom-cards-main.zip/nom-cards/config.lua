Config = {}

Config.Jobs = {
    lspd = {
        jobName = 'police',
        image = 'lspd.png',
    },
    lssd = {
        jobName = 'lssd',
        image = 'lssd.png',
    },
    -- add more if you want other jobs to be able to have their own
}

-- This is the example:
--  ('command') = {
--      jobName = ('the job name'),
--      image = ('the image inside the img folder name'),
--  },