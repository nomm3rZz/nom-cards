local Framework = exports['nom-lib']:GetLibrary()
local Config = Config or {}

-- Request jobs data from the server
TriggerServerEvent('getJobs')

RegisterNetEvent('sendJobs')
AddEventHandler('sendJobs', function(jobs)
    Config.Jobs = jobs
end)

for jobKey, jobConfig in pairs(Config.Jobs) do
    RegisterCommand(jobKey, function()
        Citizen.CreateThread(function()
            local display = false
            local startTime = GetGameTimer()
            local delay = 120000
            local Player = Framework.GetPlayerGroupInfo(true) -- Pass 'true' to get job info
            local jobName = Player.name  -- Get the job name from Player info
            if jobName == jobConfig.jobName then
                display = true
                TriggerEvent(jobKey .. ':display', true)
                TriggerEvent('anima', true)
            end

            while display do
                Citizen.Wait(1)
                ShowInfo('Press ~INPUT_CONTEXT~ to put card away.', 0)
                if (GetTimeDifference(GetGameTimer(), startTime) > delay) then
                    display = false
                    TriggerEvent(jobKey .. ':display', false)
                end
                if (IsControlJustPressed(1, 51)) then
                    cancelEmoteAndRemoveClipboard()
                    display = false
                    TriggerEvent(jobKey .. ':display', false)
                    ClearPedTasks(PlayerPedId())
                end
            end
        end)
    end)

    function cancelEmoteAndRemoveClipboard()
        local playerPed = PlayerPedId()
        ClearPedTasksImmediately(playerPed)
        local clipboardModel = GetHashKey("p_amb_clipboard_01")
        for entity in EnumerateEntitiesAttachedToPed(playerPed) do
            if GetEntityModel(entity) == clipboardModel then
                DetachEntity(entity, true, true)
                DeleteEntity(entity)
            end
        end
    end

    function EnumerateEntitiesAttachedToPed(ped)
        return coroutine.wrap(function()
            local handle, entity = FindFirstObject()
            if handle ~= -1 then
                repeat
                    if IsEntityAttachedToEntity(entity, ped) then
                        coroutine.yield(entity)
                    end
                    local success
                    success, entity = FindNextObject(handle)
                until not success
                EndFindObject(handle)
            end
        end)
    end

    RegisterNetEvent(jobKey .. ':display')
    AddEventHandler(jobKey .. ':display', function(value)
        SendNUIMessage({
            type = jobKey,
            display = value,
            jobs = Config.Jobs
        })
    end)
end

RegisterNetEvent('nom-cards:animations')
AddEventHandler('nom-cards:animations', function(id)
    Citizen.CreateThread(function()
        local display = false
        local myid = PlayerId()
        local pid = GetPlayerFromServerId(id)
        local startTime = GetGameTimer()
        local delay = 120000
        if pid ~= myid then
            if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(myid)), GetEntityCoords(GetPlayerPed(pid)), true) < 1.99 then
                local Player = Framework.GetPlayerGroupInfo(true)  -- Pass 'true' to get job info
                local jobName = Player.name  -- Get the job name from Player info

                for jobKey, jobConfig in pairs(Config.Jobs) do
                    if jobName == jobConfig.jobName then
                        display = true
                        TriggerEvent(jobKey .. ':display', true)
                    end
                end

                TriggerEvent('anima', true)

                while display do
                    Citizen.Wait(1)
                    ShowInfo('Press ~INPUT_CONTEXT~ to put card away..', 0)
                    if (GetTimeDifference(GetGameTimer(), startTime) > delay) then
                        display = false
                        for jobKey, jobConfig in pairs(Config.Jobs) do
                            TriggerEvent(jobKey .. ':display', false)
                        end
                    end
                    if (IsControlJustPressed(1, 51)) then
                        display = false
                        for jobKey, jobConfig in pairs(Config.Jobs) do
                            TriggerEvent(jobKey .. ':display', false)
                        end
                        ClearPedTasks(PlayerPedId())
                        cancelEmoteAndRemoveClipboard()
                    end
                end
            else
                for jobKey, jobConfig in pairs(Config.Jobs) do
                    TriggerEvent(jobKey .. ':display', false)
                end
                display = true
            end
        end
    end)
end)

RegisterNetEvent("anima")
AddEventHandler("anima", function(inputText)
    TriggerEvent('animations:client:EmoteCommandStart', {"clipboard"})
end)

function ShowInfo(text, state)
    SetTextComponentFormat("STRING")
    AddTextComponentString(text)
    DisplayHelpTextFromStringLabel(0, state, 0, -1)
end
