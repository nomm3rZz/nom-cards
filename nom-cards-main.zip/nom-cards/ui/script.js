$(function(){
    window.onload = function(e){
        window.addEventListener('message', function(event){
            var item = event.data;
            if (item !== undefined && item.type) {
                var jobElement = $('#job-containers');
                if (jobElement.length > 0) {
                    if (item.display === true) {
                        jobElement.delay(100).fadeIn(0);
                    } else if (item.display === false) {
                        jobElement.fadeOut("slow");
                    }
                }
            }

            if (item.jobs) {
                const jobContainers = $('#job-containers');
                jobContainers.empty();
                    const jobDiv = $("#job-containers");
                    console.log(item.type);
                    jobDiv.css('background-image', `url('img/${item.type}.png')`);
                    jobDiv.show();
            }
        });
    };
});
