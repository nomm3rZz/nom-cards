local Framework = exports['nom-lib']:GetLibrary()

RegisterNetEvent('getJobs')
AddEventHandler('getJobs', function()
    local src = source
    TriggerClientEvent('sendJobs', src, Config.Jobs)
end)