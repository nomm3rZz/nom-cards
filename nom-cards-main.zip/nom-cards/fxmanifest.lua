fx_version "bodacious"
game "gta5"

description "A card script for whatever(QBX/QB)"
author "nomm3rZz"
version "2.0.0"

ui_page 'ui/index.html'
files {
  'ui/index.html',
  'ui/img/*.png',
  'ui/style.css',
  'ui/script.js',
}

shared_script 'config.lua'
client_script 'client/*.lua'
server_script 'server/*.lua'

dependencies {
  'nom-lib',
}